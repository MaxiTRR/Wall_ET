package com.example.fragmentsandbottomnavview

import java.io.Serializable

data class Account(
    var ammount: Float
):Serializable
